-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 
-- Versão do Servidor: 5.5.24-log
-- Versão do PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `projetointegrado`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `animais`
--

CREATE TABLE IF NOT EXISTS `animais` (
  `id` int(11) NOT NULL,
  `pessoas_id` int(11) NOT NULL,
  `tipo` varchar(10) DEFAULT NULL,
  `nome` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_animais_pessoas_idx` (`pessoas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas`
--

CREATE TABLE IF NOT EXISTS `pessoas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` tinyint(4) DEFAULT NULL,
  `cpf_cnpj` varchar(20) DEFAULT NULL,
  `rg_ie` varchar(15) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `endereco` text,
  `telefone` varchar(15) DEFAULT NULL,
  `contato` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Extraindo dados da tabela `pessoas`
--

INSERT INTO `pessoas` (`id`, `tipo`, `cpf_cnpj`, `rg_ie`, `nome`, `endereco`, `telefone`, `contato`) VALUES
(1, 0, '', '', 'Rafael', '', '19199999595', 'mesmo'),
(12, 0, '', '', 'Rafael', '', '19199999595', 'mesmo'),
(13, 0, '', '', 'Rafael', '', '19199999595', 'mesmo'),
(14, 0, '', '', 'Rafael', '', '19199999595', 'mesmo'),
(15, 0, '', '', 'Rafael', '', '19199999595', 'mesmo'),
(16, 0, '', '', 'Rafael', '', '19199999595', 'mesmo'),
(17, 0, '', '', 'Rafael', '', '19199999595', 'mesmo'),
(18, 0, '', '', 'Rafael', '', '19199999595', 'mesmo'),
(19, 0, '', '', 'Rafael', '', '19199999595', 'mesmo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE IF NOT EXISTS `produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `descricao` text,
  `preco` decimal(10,2) DEFAULT NULL,
  `unidade` varchar(10) DEFAULT NULL,
  `estoque` decimal(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas`
--

CREATE TABLE IF NOT EXISTS `vendas` (
  `id` int(11) NOT NULL,
  `pessoas_id` int(11) NOT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `forma_pagamento` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vendas_pessoas_idx` (`pessoas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendas_produtos`
--

CREATE TABLE IF NOT EXISTS `vendas_produtos` (
  `produtos_id` int(11) NOT NULL,
  `vendas_id` int(11) NOT NULL,
  `quantidade` decimal(10,2) DEFAULT NULL,
  `preco_unitario` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`produtos_id`,`vendas_id`),
  KEY `fk_vp_vendas_idx` (`vendas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Restrições para as tabelas dumpadas
--

--
-- Restrições para a tabela `animais`
--
ALTER TABLE `animais`
  ADD CONSTRAINT `fk_animais_pessoas` FOREIGN KEY (`pessoas_id`) REFERENCES `pessoas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para a tabela `vendas`
--
ALTER TABLE `vendas`
  ADD CONSTRAINT `fk_vendas_pessoas` FOREIGN KEY (`pessoas_id`) REFERENCES `pessoas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Restrições para a tabela `vendas_produtos`
--
ALTER TABLE `vendas_produtos`
  ADD CONSTRAINT `fk_vp_produtos` FOREIGN KEY (`produtos_id`) REFERENCES `produtos` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vp_vendas` FOREIGN KEY (`vendas_id`) REFERENCES `vendas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
